<?php
namespace app\admin\controller;
date_default_timezone_set('PRC');
use think\Controller; //引入控制器类
use think\Image;      //引入图像
use think\Db;         //引入底层Db类
class Cate extends Allow
{
	//调整类别顺序 加分隔符
	public function getcate(){
		$cate=Db::query("select *,concat(path,',',id) as paths from cate order by paths");
		foreach($cate as $key=>$value){
			//获取path
      $path=$value['path'];
			//转换成数组
			$arr=explode(',',$path);
			//var_dump($arr);exit;
			$len=count($arr)-1;
			
      $cate[$key]['name']=str_repeat('❤',$len).$value['name'];

		}
		return $cate;

	}


    public function getindex()
    {
    	
      $cate=$this->getcate();
      $request=request();
    	
    	
       return $this->fetch('Cate/index',['cate'=>$cate]);
     
    }

    //删除
    public function getdelete(){
    	$request=request();
    	$id=$request->param('id');
      //获取当前类别下的个数
      $count=Db::table('cate')->where('pid',"{$id}")->Count();
    	//代表图片删除成功
    	if($count>0){
        echo '<script>alert("请先删除子类信息");window.location.href="/cate/index"</script>';exit;


      }

      if(Db::table('cate')->delete($id)){
    		echo '<script>alert("删除成功");window.location.href="/cate/index"</script>';
    	}else{
        echo '<script>alert("删除失败");window.location.href="/cate/index"</script>';

      }
    

    }

    //添加
    public function getadd(){
    	$cate=Db::table("cate")->select();
      
       return $this->fetch('Cate/add',['cate'=>$cate]);
    }
   

    //增加操作
    public function postinsert(){
    	$request=request();
    	$data=$request->only(['name','pid']); 
    	$pid=$request->param("pid"); 
    
    	
		//判断是否是顶级分类
    	if($pid==0){
    		//顶级分类
    		$data['path']=0;
    	
    	}else{
    		$info=Db::table('cate')->where("id","{$pid}")->find($pid);
    		//拼接path
        $data['path']=$info['path'].','.$info['id'];
    	
    	}
      
    	if(Db::table('cate')->insert($data)){
    		echo '<script>alert("添加成功");window.location.href="/cate/index"</script>';
    	}else{
        echo '<script>alert("添加失败");window.location.href="/cate/index"</script>';

      } 	
    }


    //修改
    public function getedit(){
    
    	$request=request();
    	$id=$request->param('id');
    	
      	$info=Db::table('cate')->where("id","{$id}")->find();
        //获取所有类别
      	 $data=Db::table("cate")->select();
      

      	return $this->fetch('cate/edit',['data'=>$data,'info'=>$info]);  	
    
    }
   	


    //修改操作
    public function postupdate(){
    	
    	$request=request();
    	$data=$request->param();
    	$rel=Db::table('cate')->find($data['pid']);
    	
    	$data['path']=$rel['path'].','.$rel['id'];
    	unset($data['action']);
    	
    		if(Db::table('cate')->update($data)){

      			echo '<script>alert("修改成功");window.location.href="/cate/index"</script>';
      	
      		}else{
      			echo '<script>alert("修改失败");window.location.href="/cate/index"</script>';
      		}
    
    }


      //作品展示

        public function getexhibition(){
    
        $request=request();
      
        $data=Db::table('exhibition')->select();

        return $this->fetch('cate/exhibition',['data'=>$data]);   
    
    }
    	




    //作品添加
      public function geteadd(){
    
      $cate=Db::table("cate")->select();
       return $this->fetch('Cate/eadd',['cate'=>$cate]);
    }
     public function posteinsert(){
      
        $request =request();
        $data=$request->param();
        unset($data['action']);
        $file=$request->file('pic');
       $result=$this->validate(['file1'=>$file],['file1'=>'require|image'],['file1.require'=>'上传文件不能为空','file1.img'=>'上传文件必须是图像类型']);
        if(true !== $result){
            $this->error($result,'/file/index');
        }

        //移动
        $info=$file->move(ROOT_PATH.'public'.DS.'uploads');
        $path=$info->getSavename();

        
        $data['pic']=$path;
    
        if(Db::table('exhibition')->insert($data)){
            echo '<script>alert("添加成功");window.location.href="/cate/exhibition"</script>';
        }   
    
      
    
    }

   //作品修改
    public function getexhiedit(){
    
    	$request=request();
    	$id=$request->param('id');
    	
      	$info=Db::table('exhibition')->where("id","{$id}")->find();
        //获取所有类别
      	 $data=Db::table("cate")->select();
      

      	return $this->fetch('cate/exhiedit',['data'=>$data,'info'=>$info]);  	
    
    }


    //房间展示
    public function getroom()
    {
      
    
      $request=request();
      $data=Db::table('room')->select();
      
       return $this->fetch('Cate/room',['data'=>$data]);
     
    }
        //添加
      public function getradd(){
    
  
       return $this->fetch('Cate/radd');
    }
    public function postrinsert(){
      
        $request =request();
        $data=$request->param();
        unset($data['action']);
        $file=$request->file('pic');
       $result=$this->validate(['file1'=>$file],['file1'=>'require|image'],['file1.require'=>'上传文件不能为空','file1.img'=>'上传文件必须是图像类型']);
        if(true !== $result){
            $this->error($result,'/file/index');
        }

        //移动
        $info=$file->move(ROOT_PATH.'public'.DS.'uploads');
        $path=$info->getSavename();

        
        $data['pic']=$path;
    
        if(Db::table('room')->insert($data)){
            echo '<script>alert("添加成功");window.location.href="/cate/exhibition"</script>';
        }   
    
      
    
    }







    //促销管理
    
    public function getpromotion()
    {
      
    
      $request=request();
      $data=Db::table('exhibition')->select();
      
       return $this->fetch('Cate/promotion',['data'=>$data]);
     
    }
        //添加
      public function getpadd(){
    
  
       return $this->fetch('Cate/padd');
    }
    public function postpinsert(){
      
        $request =request();
        $data=$request->param();
        unset($data['action']);
        $file=$request->file('pic');
       $result=$this->validate(['file1'=>$file],['file1'=>'require|image'],['file1.require'=>'上传文件不能为空','file1.img'=>'上传文件必须是图像类型']);
        if(true !== $result){
            $this->error($result,'/file/index');
        }

        //移动
        $info=$file->move(ROOT_PATH.'public'.DS.'uploads');
        $path=$info->getSavename();

        
        $data['pic']=$path;
    
        if(Db::table('promotion')->insert($data)){
            echo '<script>alert("添加成功");window.location.href="/cate/exhibition"</script>';
        }   
    
      
    
    }





}
	
?>