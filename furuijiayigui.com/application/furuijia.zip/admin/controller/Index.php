<?php
namespace app\admin\controller;
use think\Controller; //引入控制器类
// use think\Captcha;	  // 引入验证码
use think\Image;      //引入图像
use think\Db;         //引入底层Db类
use think\Session;
class Index extends Allow
{
   

    public function getindex()
    

    {
    	
    	//后台首页
    	
    	//把标题更换
    	$title = '我的首页';
    	return $this->fetch('Index/index',['title'=>$title]);
    }

}
