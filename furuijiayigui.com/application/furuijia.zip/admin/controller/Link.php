<?php
namespace app\admin\controller;
date_default_timezone_set('PRC');
use think\Controller; //引入控制器类
use think\Image;      //引入图像
use think\Db;         //引入底层Db类
class Link extends Allow
{
    public function getindex()
    {
    	$request=request();
       $data=Db::table('link')->paginate(7);
       $num=count($data);
       
       //订单列表
       return $this->fetch('Link/index',['data'=>$data,'request'=>$request->param(),'num'=>$num]);
    }

    //删除友情链接
    public function getdelete(){
    	$request=request();
    	$id=$request->param('id');
    	$data=Db::table('link')->find($id);
    	
    	// $path=$data['picture'];
    	// $bool=unlink(ROOT_PATH.'public/uploads/'.$path);
            if(Db::table('link')->delete($id)){
                        echo '<script>alert("删除成功");window.location.href="/link/index"</script>';
                }
    	// if($bool){
    	// 	//代表图片删除成功
    	// 	if(Db::table('link')->delete($id)){
    	// 		echo '<script>alert("删除成功");window.location.href="/link/index"</script>';
    	// 	}
    	// }

    }

    //增加链接
    public function getadd(){
    	
    	return $this->fetch('Link/add');
    }
    //增加操作
    public function postinsert(){
    	$request=request();
    	$data=$request->param();
    	unset($data['action']);

    	// $file=$request->file('picture');
    	// $result=$this->validate(['file1'=>$file],['file1'=>'require|image'],['file1.require'=>'上传文件不能为空','file1.img'=>'上传文件必须是图像类型']);
    	// if(true !== $result){
    	// 	$this->error($result,'/file/index');
    	// }

    	// //移动
    	// $info=$file->move(ROOT_PATH.'public'.DS.'uploads');
    	// $path=$info->getSavename();
    	//$ext=$info->getExtension();
    	//var_dump($path);exit;
    	//$data['picture']=$path;
    	//$data['addtime']=date('Y-m-d H-i-s');
    	//$data['status']=1;
    	if(Db::table('link')->insert($data)){
    		echo '<script>alert("添加成功");window.location.href="/link/index"</script>';
    	}else{


        } 	
    }

    //搜索
    public function getss(){
    	$request=request();
    	$ss=$request->param('ss');
    	$data=Db::table('link')->where('name','like','%'.$ss.'%')->paginate(7);
    	$num=count($data);
    	return $this->fetch('link/index',['data'=>$data,'num'=>$num,'request'=>$request->param()]);

    }

    //修改
    public function getedit(){
    	//var_dump($_GET);
    	$request=request();
    	$id=$request->param('id');
    	
      	$data=Db::table('link')->find($id);
      	//var_dump(ROOT_PATH);exit;
      	return $this->fetch('link/edit',['data'=>$data]);  	
    
    }
    //修改操作
    public function postupdate(){
    	//var_dump($_POST);
    	$request=request();
    	$data=$request->param();
    	$file=$request->file('picture');
    	//var_dump($file);exit;
    	unset($data['action']);
    	
    	//var_dump($data);
    	if(!$file==null){
    		$bool=unlink(ROOT_PATH.'public/uploads/'.$data['pic']);
    		$info=$file->move(ROOT_PATH.'public'.DS.'uploads');
    		$data['picture']=$info->getSavename();
    	}
    	
    	unset($data['pic']);
    
    		if(Db::table('link')->update($data)){

      			echo '<script>alert("修改成功");window.location.href="/link/index"</script>';
      	
      		}else{
      			echo '<script>alert("修改失败");window.location.href="/link/index"</script>';
      		}
    
    }


   

}
	
?>