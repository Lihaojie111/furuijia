<?php
namespace app\home\widget;
//导入 Controller
use think\Controller;
use think\Db;
use think\Session;	
class Cate extends Controller{
		//加载公共头
		public function header(){
			$home=Session::get('login_home');
			 $cate=Db::table('cate')->where("pid",'0')->select();
			 $nav=Db::table('navigation')->select(); 
			return $this->fetch("Cate:header",['nav'=>$nav]);

		}

		//加载公共尾
		public function footer(){
				$link =Db::table("link")->select();
			return $this->fetch("Cate:footer",["link"=>$link]);
			}

}








?>