<?php
namespace app\home\controller;
use think\Controller;
use think\Db;
use think\Session;


// class  College extends Controller
// {
 
//      //芙瑞伽商学院
//      public function  getcollege(){
//      	$request=request();
      
//       $news=Db::table('new')->select();
        
      
//       return $this->fetch("Home/shangxue",['news'=>$news]);


//      }


// }

class College extends Allow
{

    //芙瑞伽商学院
     public function  getcollege(){
     	$request=request();
      
      	$news=Db::table('new')->select();
       	return $this->fetch("Home/shangxue",['news'=>$news]);


     }
     
    

 
}



