<?php
namespace app\home\controller;
use think\Controller;
use think\Db;
use think\Request;
use think\Session;


class Index extends  Controller{
   //无限分类递归数据遍历
  public function getcatesbypid($pid){
    $data=Db::table("cate")->where("pid","{$pid}")->select();
    $data1=array();
    //遍历
    foreach($data as $value){
      //获取子类信息
      $value['shop']=$this->getcatesbypid($value['id']);
      $data1[]=$value;
    }
    return $data1;
  }
 
  public function getindex()   
    {
     
        $request=request();
        //轮播图
        $map=Db::table('map')->where('state','0')->select();
        //促销
        $promotion=Db::table('promotion')->limit(3)->select();
        //分类
        $cate=$this->getcatesbypid(0);
        //案例案例
        $exhibition=Db::table('exhibition')->limit(8)->select();
        //房间展示
        $room=Db::table('room')->limit(6)->select();
        //关于我们
        $ynopsis=Db::table('ynopsis')->find();
        //资讯中心
        $news=Db::table('new')->select();
    	//加载前台首页
    	return $this->fetch("Home/index",['map'=>$map,'cate'=>$cate,'promotion'=>$promotion,'room'=>$room,'ynopsis'=>$ynopsis,'exhibition'=>$exhibition,'news'=>$news]);



    }

    //登录
   public function getlogin(){
      

      return $this->fetch("/Home/login");     

    }
    //执行登录
    public function postdologin(){
       $request=request();
       $name=$request->param('name');
       $password=md5($request->param('password'));
        $row=Db::table("user")->where("name='{$name}' and password='{$password}' and state=1")->select();
        if($row){
            // echo "前台首页";
            //把用户登录的信息存储在session里
            Session::set('logins',2);
            Session::set('uid',$row[0]['id']);
            Session::set('username',$row[0]['name']);
            $this->success("登录成功","/college/College");
        }
    }

    //关于我们
    public function getprofile(){

        $request=request();
          //简介
        $yonpsis=Db::table('ynopsis')->find();
          //文化
        $culture=Db::table('culture')->find();
        // $yonpsis=Db::table('ynopsis')->find();
    	
        return $this->fetch("Home/profile",['yonpsis'=>$yonpsis,'culture'=>$culture]);

    }

    //新闻资讯
    public function getnews(){
       $request=request();
      
      $news=Db::table('new')->select();
        
      return $this->fetch("Home/news",['news'=>$news]);
  

    }
    //新闻查看
    public  function getnewlook(){
      $request=request();
          
        $id=$request->param('id');
         $look=Db::table('new')->where("id","{$id}")->find();
      return $this->fetch("Home/news-dec",['look'=>$look]);


    }
    //产品分类
    public function  getclassify(){
         $request=request();
        
        $room=Db::table('room')->select();

      return $this->fetch("Home/team",['room'=>$room]);

    }

    //案例展示
    public function  getexhibition(){

      $request=request();      
      $cate=Db::table('cate')->select();
      $exhibition=Db::table('exhibition')->select();     
      return $this->fetch("Home/decorate-eigth",['exhibition'=>$exhibition,'cate'=>$cate]);


    }
    
    //案例展示
    public function  getdetails(){
        $request=request();
        $id=$request->param('id');
        $exhi=Db::table('exhibition')->where("id","{$id}")->find();
        return $this->fetch("Home/decorate-nine",["exhi"=>$exhi]);


    }
    //招商加盟
     public function  getzhaoshang(){

      return $this->fetch("Home/zhaoshang");


     }
    //招商加盟添加
     public function  postdocollege(){
        $request=request();
        $data=$request->param();
        unset($data['action']);
        if(Db::table('zhaoshang')->insert($data)){
        echo '<script>alert("添加成功");window.location.href="/Home/zhaoshang"</script>';
      }
        
        
        

     }
     //产品分类描述
      public function getdescribes(){
         
          //$room=Db::table('room')->where('id',"{$id}")->find();

      

         return $this->fetch("Home/opiys");

      }

}
